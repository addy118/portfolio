"use client";

import { Button } from "@/components/ui/button";

export default function IntroSection() {
  const downloadResume = () => {
    // Replace with actual Google Drive document ID
    const docId = "REPLACE_WITH_YOUR_DOC_ID";
    const downloadUrl = `https://drive.google.com/uc?export=download&id=${docId}`;
    window.open(downloadUrl, "_blank");
  };

  return (
    // <section id="intro" className="py-20 px-4 sm:px-6 lg:px-8 relative">
    <section className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold mb-8 text-[#F1F0EA] font-mono">
          Hello! I'm <span className="text-[#00A6ED]">&#123; </span> Aditya
          Kirti <span className="text-[#00A6ED]">&#125;</span>
        </h2>
        <p className="text-lg font-mono sm:text-xl text-[#F1F0EA]/80 mb-8 w-100 text-balance">
          A third year B.E. in IT student who is curiously learning{" "}
          <span className="text-[#00A6ED]">full stack web development</span> and
          trying to{" "}
          <span className="text-[#00A6ED]">solve real-world problems</span> by
          making a software solution for them.
        </p>
        <p className="text-lg font-mono sm:text-xl text-[#F1F0EA]/80 mb-8 w-100 text-balance">
          I love <span className="text-[#00A6ED]">leetcoding</span> and finding
          ways to how data structures and algorithms help in my every day{" "}
          <span className="">life</span>.
        </p>
        <Button
          onClick={downloadResume}
          className="bg-[#0A0A0A]/80 hover:bg-[#040404]/70 border-[#00A6ED]/20 text-[#00A6ED]/90 px-6 py-3 text-lg font-mono rounded-lg transition-all duration-100 border"
        >
          Download Resume
        </Button>
      </div>
    </section>
  );
}
