import React, { FC } from "react";
import { Skill } from "./why-aditya-section";

export const RenderSkill: FC<{ skills: Skill[] }> = ({ skills }) => {
  return (
    <div className="flex gap-4 mb-4 items-center justify-center">
      {skills.map((skill, i) => (
        // <SkillCard skill={skill} key={i} />
        <div
          key={i}
          className="text-lg font-medium text-[#F1f0ea]/70 bg-[#00A6ED]/10 px-4 py-2 gap-2 flex items-center justify-between rounded-full max-w-max"
        >
          <img
            width="30"
            src={skill.image}
            alt={skill.name}
            title={skill.name}
          />
          <div>{skill.name}</div>
        </div>
      ))}
    </div>
  );
};
