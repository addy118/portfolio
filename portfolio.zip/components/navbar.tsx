"use client";

import { useState, useEffect } from "react";

const navItems = [
  { name: "Showcase", href: "#showcase" },
  { name: "Performance", href: "#performance" },
  { name: "Blog", href: "https://dev.to/adityakirti", external: true },
  { name: "Installation", href: "#installation" },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-20 right-20 font-mono z-50 rounded-lg m-4 my-6 transition-all duration-300 ${
        isScrolled
          ? "bg-[#0A0A0A]/80 backdrop-blur-md border-b border-[#00A6ED]/20"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <span className="text-xl font-bold text-[#00A6ED]">
              Aditya Kirti
            </span>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => {
                    if (item.external) {
                      window.open(item.href, "_blank");
                    } else {
                      scrollToSection(item.href);
                    }
                  }}
                  className="text-[#F1F0EA] hover:text-[#00A6ED] px-3 py-2 text-sm font-medium transition-colors duration-200"
                >
                  {item.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
