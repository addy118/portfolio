"use client";

import { Card, CardContent } from "@/components/ui/card";

const projects = [
  {
    name: "Fairshare",
    description: [
      "A smart, responsive full-stack PWA to manage and split group expenses with ease.",
      "Implemented secure Google OAuth login, direct UPI payments, PDF exports, email reminders, and a custom optimization algorithm that reduces settlement steps by up to 60%.",
    ],
    link: "https://fairshare.adityakirti.tech",
    image: "/fairshare_1898x863.png",
    stack:
      "TypeScript, PostgreSQL, React, Redux, RTK Query, Express, Node.js, Tailwind",
  },
  {
    name: "Cloudvault",
    description: [
      "A full-stack on-the-go cloud storage for uploading, retrieving, and sharing files with up to 10-file batch uploads and 99% uptime.",
      "Features secure JWT auth with auto token rotation, intuitive breadcrumb navigation, and Supabase-powered storage with shareable links and 5MB/file upload limit.",
    ],
    link: "https://cloudvault.adityakirti.tech",
    image: "/cloudvault_1919x904.png",
    stack: "PostgreSQL, React, Multer, Express, Node.js, Supabase, Tailwind",
  },
];

export const ShowcaseSection = () => {
  return (
    <section
      id="showcase"
      className="py-20 px-4 sm:px-6 lg:px-8 text-center relative font-mono"
    >
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl mb-8 font-bold text-[#F1F0EA]">
            Showcase
          </h2>
          <p className="text-[#00A6ED] text-balance text-lg mb-4">
            Some tools I've designed and developed from scratch to solve
            real-world problems.
          </p>
        </div>
        <div className="space-y-12">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="bg-[#0A0A0A]/80 border-[#00A6ED]/20 overflow-hidden transition-all duration-300 backdrop-blur-sm"
            >
              <CardContent className="p-0">
                <div
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-0 ${
                    index % 2 === 1 ? "lg:grid-flow-col-dense" : ""
                  }`}
                >
                  <div
                    className={`p-8 flex flex-col justify-between ${
                      index % 2 === 1 ? "lg:col-start-2" : ""
                    }`}
                  >
                    <div>
                      <h3 className="text-2xl font-bold mb-4 text-[#00A6ED]">
                        {project.name}
                      </h3>
                      <p className="text-[#F1F0EA]/70 text-lg mb-6 px-4 leading-relaxed text-justify">
                        {project.description.map((list, i) => (
                          <li
                            key={i}
                            className="text-justify font-extralight text-base py-2"
                          >
                            {list}
                          </li>
                        ))}
                      </p>
                    </div>

                    <p className="font-extralight text-[#00A6ED]/80 px-6">
                      {project?.stack}
                    </p>
                  </div>
                  <div
                    className={`flex items-center justify-center p-8 ${
                      index % 2 === 1 ? "lg:col-start-1" : ""
                    }`}
                  >
                    <img
                      src={project.image}
                      alt={project.name}
                      width={500}
                      height={300}
                      className="w-[500px] h-[300px] object-cover rounded"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
